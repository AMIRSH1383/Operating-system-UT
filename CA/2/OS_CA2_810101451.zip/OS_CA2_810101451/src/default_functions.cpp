#include "default_functions.hpp"

#include <sstream>
#include <string>
#include <vector>

std::vector<std::string> split_line(const std::string& line, char delim) 
{
    std::vector<std::string> result;
    std::istringstream line_stream(line);
    while (!line_stream.eof()) {
        std::string temp;
        std::getline(line_stream, temp, delim);
        result.push_back(temp);
    }
    return result;
}
