#ifndef LOG_HPP
#define LOG_HPP

#include <ostream>
#include <iostream>
#include <chrono>
#include <ctime>

#define INFO "Info: "
#define ERROR "Error: "
#define WARNING "Warning: "
#define TODAY "Today is: "

class Log {
public:
    Log(const std::string& logger, bool has_label, bool has_time_header);

    void info(const std::string& info);
    void error(const std::string& error);
    void warning(const std::string& warning);

private:
    std::ostream& _info_stream = std::cout;
    std::ostream& _error_stream = std::cerr;
    std::ostream& _warning_stream = std::cout;
    
    std::string _logger;

    bool _has_label = false;
    bool _has_time_header = false;

    void add_time_header(std::ostream& stream);
};

#endif
