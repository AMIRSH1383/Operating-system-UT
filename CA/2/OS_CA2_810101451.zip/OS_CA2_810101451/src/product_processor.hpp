#ifndef PRODUCT_PROCESSOR_HPP
#define PRODUCT_PROCESSOR_HPP

#include <string>
#include <vector>

#include "named_pipe.hpp"
#include "log.hpp"
#include "structs.hpp"
#include "consts.hpp"

class ProductProcessor 
{
public:
    ProductProcessor(const std::string& product_name, Log log);

    void run();

private:
    int _leftover;
    float _profit;
    float _lefover_value;
    std::string _product_name;
    std::vector<CityStore> _cities_product;
    NamedPipeClient _product_pipe;
    NamedPipeServer _server_pipe;
    Log _log;

    void send_result();
    void sum_up_datas();
};

#endif
