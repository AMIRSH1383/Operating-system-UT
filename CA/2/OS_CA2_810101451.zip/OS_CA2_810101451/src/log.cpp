#include "log.hpp"

#include <iostream>
#include <ratio>
#include <ostream>

Log::Log(const std::string& logger, bool has_label, bool has_time_header):
    _logger(logger),
    _has_label(has_label),
    _has_time_header(has_time_header)
{
    
}

void Log::info(const std::string& info) 
{
    if (_has_time_header)
        add_time_header(_info_stream);

    if (_has_label)
        _info_stream << INFO + _logger;

    _info_stream << info << '\n';
}

void Log::error(const std::string& error) {
    if (_has_time_header)
        add_time_header(_error_stream);
    if (_has_label)
        _error_stream << ERROR + _logger;

    _error_stream << error << '\n';
}

void Log::warning(const std::string& warning) {
    if (_has_time_header)
        add_time_header(_warning_stream);
    if (_has_label)
        _warning_stream << WARNING + _logger;

    _warning_stream << warning << '\n';
}

void Log::add_time_header(std::ostream& stream) 
{
    std:: time_t current_time = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    stream << std::ctime(&current_time);
}
