#ifndef CITY_PROCESSOR_HPP
#define CITY_PROCESSOR_HPP

#include <string>

#include <vector>

#include "log.hpp"

#include "structs.hpp"


class CityProcessor {
public:
    CityProcessor(std::string file_path, std::vector<std::string> products, Log log);

    void run();

private:
    const std::string _file_path;

    std::vector<std::string> _chosen_products;

    std::vector<Product> _products;

    std::vector<CityStore> _city_stores;
    
    bool is_done_ = false;

    Log _log;

    void read_data_from_cities_file();
    void send_result_to_product_processes();
    void compute_data_city_store();
};

#endif
