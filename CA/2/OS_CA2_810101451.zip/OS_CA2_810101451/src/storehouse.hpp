#ifndef STORE_HOUSE_HPP
#define STORE_HOUSE_HPP

#include <map>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "log.hpp"
#include "named_pipe.hpp"
#include "structs.hpp"

class Storehouse {
public:
    Storehouse(Log log);

    std::vector<CityStore> compute_storage_information();

    void set_directory_name(std::string dir_name);

    std::vector<std::string> get_products();
    void edit_products_list(std::vector<std::string>l);

private:
    std::string _dir_name;
    std::unordered_map <int, std::string> _city_processes_map;
    std::vector<std::string> _products;
    std::vector<CityStore> _products_info;
    NamedPipeServer _server_pipe;
    Log _log;

    void get_parts_from_file();

    std::vector<std::string> get_names_of_cities();
    void wait_for_city_process();

    void make_products_processes();
    void make_cities_processes();

    void get_results_from_product_processes();
};











#endif