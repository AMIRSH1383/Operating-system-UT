#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include "city_processor.hpp"
#include "log.hpp"

int main(int argc, char const* argv[]) 
{
    std::string logger_name = (argc > 1) ? std::string(argv[1]) : "city processor";
    Log log(logger_name, true, true);

    if (argc < 2) {
        log.error("City name is missing");
        exit(EXIT_FAILURE);
    }

    std::string city_file_name(argv[1]);

    int num_of_products;
    std::cin >> num_of_products;
    std::vector<std::string> products;
    while (num_of_products != 0) 
    {
        std::string temp;
        std::cin >> temp;
        products.push_back(temp);
        num_of_products--;
    }

    CityProcessor processor(city_file_name, products, log);
    processor.run();

    return 0;
}
