#ifndef CONSTS_HPP
#define CONSTS_HPP

#include <string>

namespace Consts {

const std::string PARTS_FILE_NAME  = "Parts.csv";

const std::string MAIN_STOREHOUSE_PIPE_NAME = "./storehouse_pipe";

const std::string PRODUCT_PROCESS_PATH = "./product_process";

const std::string STOREHOUSE_PIPE_NAME = "./storehouse_pipe";

const std::string CITY_PROCESS_PATH = "./city_process";

const std::string GETTING_FILES_WITH_CITIES_NAME = "Getting cities name file. ";

namespace PipeCommands 
{
    const std::string UPDATE_STORE_HOUSE = "update_store_house";

    const std::string FINISH_PRODUCT_PROCESS = "finish_product_process";
}

} 

#endif