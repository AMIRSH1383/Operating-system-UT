#include <stdexcept>
#include <string>

#include "product_processor.hpp"
#include "log.hpp"

int main(int argc, char const* argv[]) 
{
    std::string logger_name = (argc > 1) ? std::string(argv[1]) : "product processor";
    Log log(logger_name, true, true);

    if (argc <= 1) 
    {
        log.error("Product name arg missing.");
        exit(EXIT_FAILURE);
    }

    std::string product_name(argv[1]);
    ProductProcessor processor(product_name, log);
    processor.run();
    return 0;
}
