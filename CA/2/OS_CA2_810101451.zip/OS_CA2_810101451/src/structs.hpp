#ifndef STRUCT_HPP
#define STRUCT_HPP

#include <string>


typedef struct 
{
    std:: string name;
    double price;
    int quantity;
    std::string sell_or_buy;
    bool is_used;
} Product;

typedef struct 
{
    std:: string name;
    int leftover;
    double leftover_value;
    double total_profit;
} CityStore;


#endif