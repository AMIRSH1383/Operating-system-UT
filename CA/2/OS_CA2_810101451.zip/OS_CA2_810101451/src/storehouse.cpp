#include "storehouse.hpp"

#include <dirent.h>
#include <sys/wait.h>
#include <unistd.h>

#include <algorithm>
#include <fstream>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "consts.hpp"
#include "log.hpp"
#include "named_pipe.hpp"


Storehouse:: Storehouse(Log log)
    : _server_pipe(Consts:: MAIN_STOREHOUSE_PIPE_NAME)
    , _log(log)
{}

std::vector<CityStore> Storehouse :: compute_storage_information()
{
    make_products_processes();
    make_cities_processes();
    wait_for_city_process();
    get_results_from_product_processes();
    return _products_info;
}

void Storehouse:: set_directory_name(std::string dir_name)
{
    _dir_name = dir_name;
    get_parts_from_file();
}

std::vector<std::string> Storehouse:: get_products(){return _products;}

void Storehouse:: edit_products_list(std::vector<std::string>l)
{
    std::vector<std::string> temp_vec;
    for(int i = 0 ; i < _products.size() ; i++)
    {
        bool does_exist = false;
        for(std::string s:l)
        {
            if(_products[i] == s)
            {    
                std::cout<<s << s.size()<<'\n';
                does_exist = true;
                break;
            }
        }
        if(does_exist == false)
            temp_vec.push_back(_products[i]);
            
    }

    for ( auto s : temp_vec)
    {
        for (int i = 0;  i < _products.size() ; i++)
        {
            if(_products[i]==s)
            {
                _products.erase(_products.begin() + i);
                break;
            }
        }
    }
}

void Storehouse::get_parts_from_file() 
{
    _log.info("Getting products from Parts.csv. ");
    std::string parts_file_path = _dir_name + "/" + Consts::PARTS_FILE_NAME;

    std::ifstream parts_stream(parts_file_path.c_str());

    if (!parts_stream.is_open())
        throw std::runtime_error("Couldn't open parts file.");

    while (!parts_stream.eof()) 
    {
        std::string current_product;
        std::getline(parts_stream, current_product, ',');
        _products.push_back(current_product);
    }
    _products[_products.size()-1].pop_back();
    parts_stream.close();
}

std::vector<std::string> Storehouse:: get_names_of_cities()
{
    _log.info(Consts::GETTING_FILES_WITH_CITIES_NAME);
    DIR* dir;
    struct dirent* entity;
    if ((dir = opendir(_dir_name.c_str())) == NULL)
    {
        throw std::runtime_error("Given directory doesn't exist.");
    }
    std::vector<std::string> cities;
    while ((entity = readdir(dir)) != NULL) 
    {
        cities.push_back(std::string(entity->d_name));
    }

    cities.erase(std::find(cities.begin(), cities.end(), "."));
    cities.erase(std::find(cities.begin(), cities.end(), ".."));
    cities.erase(std::find(cities.begin(), cities.end(), Consts::PARTS_FILE_NAME));

    // In cities name now there is all files that are in this directory with .csv postfix excluded Parts.csv

    closedir(dir);
    return cities;
}

void Storehouse::wait_for_city_process() 
{
    _log.info("Waiting for city processes to finish.");
    while (!_city_processes_map.empty()) 
    {
        int return_status;
        int pid = wait(&return_status);
        if (return_status != EXIT_SUCCESS)
            throw std::runtime_error("An error has occurred in city process.");
        _log.info(_city_processes_map[pid] + " finished.");
        _city_processes_map.erase(_city_processes_map.find(pid));
    }
}

void Storehouse:: make_products_processes()
{
    _log.info("Making product processes. ");
    for(std::string temp_product : _products)
    {
        int pid = fork();
        if(pid > 0)
            continue;
        else if(pid == 0)
        {
            execl(Consts::PRODUCT_PROCESS_PATH.c_str(), "product_process", temp_product.c_str(), (char*)NULL);
        }
    }
}

void Storehouse:: make_cities_processes()
{
    _log.info("Making cities processes. ");
    std:: vector<std::string>cities = get_names_of_cities();
    for(std::string city : cities)
    {
        int pipe_fds[2]; //We want to open a pipe between main storage and each city
        std:: string pipe_info = "Creating pipe between main storage and city: " + city;
        Log temp_log(pipe_info,false,false);
        if (pipe(pipe_fds) == -1)
        {           
            temp_log.error("Couldn't open pipe between main and city process.");
        }
        int pid = fork();
        if(pid > 0) //Father
        {
            close(pipe_fds[0]);// The parent process only writes to the pipe, so the read-end is not needed
            std::string products_count = std::to_string(_products.size()) + ' ';
            write(pipe_fds[1], products_count.c_str(), products_count.size());
            for (int i = 0; i < _products.size(); i++) 
            {
                std::string to_write = _products[i] + " ";
                write(pipe_fds[1], to_write.c_str(), to_write.size());
            }
            _city_processes_map[pid] = city;
        }

        else if(pid == 0)//Child
        {
            close(0);//Close the standard input (stdin) file descriptor
            dup2(pipe_fds[0], 0);//Standard input operations in the child process (cin) will read data from the pipe instead
            close(pipe_fds[0]);
            close(pipe_fds[1]);//Close the write-end of the pipe in the child process
            std::string city_file_name = _dir_name + "/" + city;
            execl(Consts::CITY_PROCESS_PATH.c_str(), "city_process", city_file_name.c_str(), (char*)NULL);
        }
    }
}

void Storehouse::get_results_from_product_processes() 
{
    _log.info("Gathering results. ");
    for (const auto& product : _products) 
    {
        std::string pipe_name = product;
        NamedPipeClient client_pipe(pipe_name);
        std::string pipe_cmd = Consts::PipeCommands::FINISH_PRODUCT_PROCESS + '\n';
        client_pipe.send(pipe_cmd);
    }

    std::istringstream product_str(_server_pipe.receive());
    std::string product_name;
    while (product_str >> product_name) 
    {
        std:: string str;
        CityStore product_info;
        product_info.name = product_name;

        product_str >> str;
        product_info.leftover = std::stoi(str);

        product_str >> str;
        product_info.leftover_value = std::stod(str);

        product_str >> str;
        product_info.total_profit = std::stod(str);

        _products_info.push_back(product_info);
    }
}
