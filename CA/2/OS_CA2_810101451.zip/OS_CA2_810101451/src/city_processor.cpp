#include "city_processor.hpp"

#include <string>
#include <vector>
#include <algorithm>
#include <fstream>

#include "default_functions.hpp"
#include "named_pipe.hpp"
#include "consts.hpp"


CityProcessor:: CityProcessor(std::string file_path, std::vector<std::string> products, Log log):
     _file_path(file_path), // Example: stores/Tehran.csv
     _log(log),   
     _chosen_products(products) 
{

}

void CityProcessor::run() 
{
    read_data_from_cities_file();
    compute_data_city_store();
    send_result_to_product_processes();
}

void CityProcessor::read_data_from_cities_file()
{
    std::ifstream part_file;
    part_file.open(_file_path);
    if (!part_file.is_open())
        throw std::runtime_error("Can't open part file.");

    while (!part_file.eof()) 
    {
        std::string current_line;
        std::getline(part_file, current_line);

        std::vector<std::string> parsed_line = split_line(current_line, ',');
        auto it = std::find(_chosen_products.begin(), _chosen_products.end(), parsed_line[0]);
        if(it != _chosen_products.end())
        {
            Product new_product;
            new_product.name = parsed_line[0];            
            new_product.price = std::stod(parsed_line[1]);
            new_product.quantity = std::stoi(parsed_line[2]);

            parsed_line[3].pop_back();
            new_product.sell_or_buy = parsed_line[3];
            new_product.is_used = false;
            _products.push_back(new_product);
        }
    }
}

void CityProcessor::compute_data_city_store()
{
    for(std::string p : _chosen_products)
    {
        auto temp_vec = _products;
        float profit = 0;
        for(int i = 0 ; i < _products.size() ; i++)
        {
            if(_products[i].name == p)
            {
                if(_products[i].sell_or_buy == "output" && _products[i].is_used == false)
                {
                    for(int j = 0; j < _products.size() ; j++)
                    {
                       if(_products[j].name == p && _products[j].sell_or_buy == "input" && _products[j].is_used == false)
                       {
                            if(_products[i].quantity >= _products[j].quantity)
                            {
                                profit += (_products[j].quantity * (_products[i].price - _products[j].price));
                                _products[i].quantity -=_products[j].quantity;
                                _products[j].quantity = 0;
                            }
                            
                            else
                            {
                                profit += (_products[i].quantity * (_products[i].price - _products[j].price));
                                _products[j].quantity -= _products[i].quantity;
                                _products[i].quantity = 0 ;
                            }
                       }

                        if(_products[j].quantity == 0)
                            _products[j].is_used = true;
                        if(_products[i].quantity == 0)
                        {
                            _products[i].is_used = true;
                        }
                    }
                }
            }
        }

        int leftover = 0;
        float leftover_value = 0;
        for (int i = 0 ; i < _products.size() ; i++)
        {
            if(_products[i].name == p)
            {
                if(_products[i].is_used == false && _products[i].sell_or_buy == "input")
                {
                    leftover+=_products[i].quantity;
                    leftover_value += (_products[i].quantity * _products[i].price);
                }
            }
        }
        CityStore city_store;
        city_store.name = p;
        city_store.leftover = leftover;
        city_store.leftover_value = leftover_value;
        city_store.total_profit = profit;
        _city_stores.push_back(city_store);
    }
}

void CityProcessor:: send_result_to_product_processes()
{
    for (auto p : _city_stores) 
    {
        NamedPipeClient client_pipe(p.name);// Make a client side to send msgs to product process pipe
        
        std::string command_to_send =
        Consts::PipeCommands::UPDATE_STORE_HOUSE + " " + std::to_string(p.leftover)+ " " + std::to_string(p.leftover_value)+ " " + std::to_string(p.total_profit) + "\n";
        client_pipe.send(command_to_send);
    }
}