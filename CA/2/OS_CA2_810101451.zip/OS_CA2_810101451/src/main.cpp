#include <iostream>
#include <stdexcept>

#include "storehouse.hpp"
#include "log.hpp"
#include "default_functions.hpp"

#define STOREHOUSE_MANAGEMENT "Storehouse management. "
#define MISSING_DIRECTORY_NAME "Directory name was not written. "

int main(int argc, char const* argv[]) 
{
    Log log(STOREHOUSE_MANAGEMENT, true, true);
    if (argc < 2) 
    {
        log.error(MISSING_DIRECTORY_NAME);
        exit(EXIT_FAILURE);
    }

    std::string dir_name(argv[1]);
    
    Storehouse store_house(log);
    store_house.set_directory_name(dir_name);
    auto products = store_house.get_products();
    std::cout << "Choose as many products as you want.(Example: berenj,roghan,...)\n";
    for(int i = 0; i < products.size();i++)
    {
        std::cout << i+1 << ": " << products[i] << '\n';
    }

    std::string input;
    std::getline(std::cin, input); 
    auto chosen_products = split_line(input,',');
    store_house.edit_products_list(chosen_products);
    
    auto result_products = store_house.compute_storage_information();  

    float final_profit = 0;
    for(auto product : result_products)
    {
        std:: cout << "Information about product: " << product.name << '\n';
        std:: cout << "Total leftover: " << product.leftover << '\n';
        std:: cout << "Total leftover value: " << std::to_string(product.leftover_value) << '\n';
        std:: cout << "Total profit: " << product.total_profit << '\n';
        std:: cout << '\n';
        final_profit += product.total_profit;
    }
    std:: cout << "Total profit for these products is: " << final_profit << '\n';
    
    return 0;
}