#include "product_processor.hpp"

#include <sstream>
#include <string>


ProductProcessor::ProductProcessor(const std::string& product_name, Log log)
    : _product_name(product_name),
      _product_pipe(NamedPipeClient(Consts::STOREHOUSE_PIPE_NAME)),
      _server_pipe(NamedPipeServer(product_name)),
      _log(log) 
{
    _leftover = 0;
    _lefover_value = 0;
    _profit = 0;
    _log.info("Created named pipe " + product_name + ".");
}

void ProductProcessor::run() 
{
    bool is_finished = false;
    while (!is_finished) 
    {
        std::string current_pipe_command = _server_pipe.receive();
        std::istringstream pipe_command_str(current_pipe_command);
        std::string command;
        while (pipe_command_str >> command) 
        {
            if (command == Consts::PipeCommands::UPDATE_STORE_HOUSE) 
            {
                std::string temp;
                CityStore store_product;
                store_product.name = _product_name;

                pipe_command_str >> temp;
                store_product.leftover = std::stoi(temp);

                pipe_command_str >> temp;
                store_product.leftover_value = std::stod(temp);

                pipe_command_str >> temp;
                store_product.total_profit = std::stod(temp);

                _cities_product.push_back(store_product);
            }
            else if (command == Consts::PipeCommands::FINISH_PRODUCT_PROCESS) 
            {
                sum_up_datas();
                _log.info("Sending results.");
                send_result();
                is_finished = true;
                break;
            }
        }
    }
}

void ProductProcessor:: sum_up_datas()
{
    for(auto p : _cities_product)
    {
        _leftover += p.leftover;
        _lefover_value += p.leftover_value;
        _profit += p.total_profit;
    }
}

void ProductProcessor::send_result() 
{
    std::ostringstream result_stream;
    result_stream << _product_name ;
    result_stream << ' ' << _leftover;
    result_stream << ' ' << _lefover_value;
    result_stream << ' ' << _profit << '\n';
    _product_pipe.send(result_stream.str());
}
