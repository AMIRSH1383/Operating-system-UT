#ifndef DFUNC_HPP
#define DFUNC_HPP

#include <string>
#include <vector>

std::vector<std::string> split_line(const std::string& line, char delim);

#endif
