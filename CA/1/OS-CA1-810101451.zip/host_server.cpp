#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <poll.h>
#include <string>
#include <unistd.h>

using namespace std;
typedef struct pollfd pollfd;

#define STDIN 0
#define STDOUT 1
#define BUFFER_SIZE 1024
#define NAME "Name:"
#define ROOM "Room:"
#define MOVE "Move:"
#define END_GAME "end_game"
#define SHOW_ROOM "show_rooms"

#define ROCK "rock"
#define PAPER "paper"
#define SCISSOR "scissor"
#define NOTHING "Move: nothing"
#define DO_NOTHING_MOVE "nothing"

const char* DRAW = "Draw!\n";
const char* WIN = "You won!\n";
const char* LOSS = "You lost!\n";
const char* SERVER_LAUNCHED = "Server Launched!\n";
const char* NEW_CONNECTION = "New Connection!\n";
const char* ASKING_FOR_NAME = "Please enter your name. Start with Name:...\n";
const char* ASKING_FOR_MOVE = "Choose between rock, paper and scissor. Start with Move:...\n";
const char* ROOM_IS_FULL = "This room is full right now. Please wait or choose another rooms!\n";
const char* ROOM_NOT_EXIST = "This room does not exist!\n";

struct players
{
    pollfd player_fd;
    string player_name;
    int num_of_wins;
    int num_of_plays;
};

struct rooms
{
    int room_number;
    vector<players> room_players; 
    vector<int>moves;
};

int make_host(char* argv [],int opt)
{   
    struct sockaddr_in server_addr;
    char* ipaddr = argv[1];
    int server_fd_private;
    server_addr.sin_family = AF_INET;
    if(inet_pton(AF_INET, ipaddr, &(server_addr.sin_addr)) == -1)
        perror("FAILED: Input ipv4 address invalid");
    else
        printf("SUCCEED: Input ipv4 address is valid\n");

    if((server_fd_private = socket(PF_INET, SOCK_STREAM, 0)) == -1)
        perror("FAILED: Socket was not created");
    else
        printf("SUCCEED: Socket was created\n");

    if(setsockopt(server_fd_private, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) == -1)
        perror("FAILED: Making socket reusable failed");
    else
        printf("SUCCEED: Making socket reusable succeed\n");

    if(setsockopt(server_fd_private, SOL_SOCKET, SO_REUSEPORT, &opt, sizeof(opt)) == -1)
        perror("FAILED: Making socket reusable port failed");
    else
        printf("SUCCEED: Making socket reusable port succeed\n");

    memset(server_addr.sin_zero, 0, sizeof(server_addr.sin_zero));
    
    server_addr.sin_port = htons(strtol(argv[2], NULL, 10));

    if(bind(server_fd_private, (const struct sockaddr*)(&server_addr), sizeof(server_addr)) == -1)
        perror("FAILED: Bind unsuccessfull");
    else
        printf("SUCCEED: Bind successfull\n");

    if(listen(server_fd_private, 20) == -1)
        perror("FAILED: Listen unsuccessfull");
    else
        printf("SUCCEED: Listen successfull\n");

    return server_fd_private;
}

int make_broadcast(char* argv[],int opt,int broadcast,struct sockaddr_in *bc_address)
{
    int server_fd_broadcast;

    char* ipaddr = argv[1];

    server_fd_broadcast = socket(AF_INET, SOCK_DGRAM, 0);
    setsockopt(server_fd_broadcast, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(broadcast));
    setsockopt(server_fd_broadcast, SOL_SOCKET, SO_REUSEPORT, &opt, sizeof(opt));

    bc_address->sin_family = AF_INET; 
    bc_address->sin_port = htons(1060); 
    bc_address->sin_addr.s_addr = inet_addr("255.255.255.255");

    bind(server_fd_broadcast, (struct sockaddr *)bc_address, sizeof(*bc_address));

    return server_fd_broadcast;
}

vector <string> parse_line(char buffer[])
{
    string full_line = buffer;
    vector <string> words;
    for (int i = 0; i<full_line.length();i++)
    {   
        string b ="";
        while(full_line[i] != ' ' && full_line[i] != '\n')
        {
            b+=full_line[i];
            i++;
        }
        words.push_back(b);
    }
    return words;
}

void run_end_game (vector<players> players_data,int bc_fd,char* ipaddr,struct sockaddr_in bc_address)
{
    for (int i = 0; i < players_data.size() - 1; i++) {
        // Last i elements are already
        // in place
        for (int j = 0; j < players_data.size() - i - 1; j++) {
              // Comparing adjacent elements
            if (players_data[j].num_of_wins < players_data[j+1].num_of_wins)
                  // Swapping if in the wrong order
                swap(players_data[j], players_data[j+1]);
        }
    }

    for(int i = 0;i < players_data.size();i++)
    {
        players temp_player = players_data[i];
        char tmp[128]={0x0};
        int tmp_size = sprintf(tmp,"\nPlayer name: %s\nGames played: %d\nWins: %d\n",temp_player.player_name.c_str(),temp_player.num_of_plays,temp_player.num_of_wins);
        sendto(bc_fd, tmp, tmp_size, 0,(struct sockaddr *)&bc_address, sizeof(bc_address));    
    }
}

vector <int> show_available_rooms(vector<rooms> playroom)
{
    vector <int> avail_room;
    for(int i = 0 ; i < playroom.size() ; i++)
    {
        if(playroom[i].room_players.size() < 2)
        {
            avail_room.push_back(playroom[i].room_number);
        }
    }
    return avail_room;
}

void show_available_rooms(int fd , vector<int> rooms_available)
{
    char tmp1[128]={0x0};
    int tmp1_size = sprintf(tmp1,"Open rooms are as follows:\n");
    send(fd, tmp1, tmp1_size, 0);
    for(int i = 0;i < rooms_available.size();i++)
    {
        char tmp2[128]={0x0};
        int tmp2_size = sprintf(tmp2,"%d\t",rooms_available[i]);
        send(fd, tmp2, tmp2_size, 0);    
    }
    char tmp3[128]={0x0};
    int tmp3_size = sprintf(tmp3,"\nPlease start your command with Room:...\n");
    send(fd, tmp3, tmp3_size, 0);
}

void add_player_to_the_room(vector<rooms>*playroom,vector<players>players_data,int fd,int room_num)
{
    for (int i = 0 ; i < players_data.size();i++)
    {
        if(players_data[i].player_fd.fd == fd)
        {
            (*playroom)[room_num-1].room_players.push_back(players_data[i]);
            (*playroom)[room_num-1].moves.push_back(-1);
        }
    }   
    if((*playroom)[room_num-1].room_players.size() == 2)
    {
        send((*playroom)[room_num-1].room_players[0].player_fd.fd, ASKING_FOR_MOVE, strlen(ASKING_FOR_MOVE), 0);
        send((*playroom)[room_num-1].room_players[1].player_fd.fd, ASKING_FOR_MOVE, strlen(ASKING_FOR_MOVE), 0);
    }
}

void update_players_data(vector<players> *players_data,bool draw , players winner , players loser)
{
    for(int i = 0; i< (*players_data).size(); i++)
    {
        if(draw)
        {
            if(winner.player_fd.fd == (*players_data)[i].player_fd.fd)
            {
                (*players_data)[i].num_of_plays++;
            }
            else if(loser.player_fd.fd == (*players_data)[i].player_fd.fd)
            {
                (*players_data)[i].num_of_plays++;
            }
        }
        else
        {
            if(winner.player_fd.fd == (*players_data)[i].player_fd.fd)
            {
                (*players_data)[i].num_of_plays++;
                (*players_data)[i].num_of_wins++;
            }
            else if(loser.player_fd.fd == (*players_data)[i].player_fd.fd)
            {
                (*players_data)[i].num_of_plays++;
            }
        }
    }
}

void calculate_result (vector<rooms>*playroom , vector<players> *players_data,int room_index,int bc_fd,struct sockaddr_in bc_address)
{
    players winner;
    players loser;
    bool draw = false;
    if((*playroom)[room_index].moves[0]== 0)
    {
        if((*playroom)[room_index].moves[1]==1)
        {
            winner = (*playroom)[room_index].room_players[1];
            loser = (*playroom)[room_index].room_players[0];
        }
        else if((*playroom)[room_index].moves[1]==2)
        {
            winner = (*playroom)[room_index].room_players[0];
            loser = (*playroom)[room_index].room_players[1];
        }
        else if((*playroom)[room_index].moves[1] == 3)
        {
            winner = (*playroom)[room_index].room_players[0];
            loser = (*playroom)[room_index].room_players[1];
        }
        else
            draw = true;
    }
    else if((*playroom)[room_index].moves[0]==1)
    {
        if((*playroom)[room_index].moves[1]==2)
        {
            winner = (*playroom)[room_index].room_players[1];
            loser = (*playroom)[room_index].room_players[0];
        }
        else if((*playroom)[room_index].moves[1]==0)
        {
            winner = (*playroom)[room_index].room_players[0];
            loser = (*playroom)[room_index].room_players[1];
        }
        else if((*playroom)[room_index].moves[1] == 3)
        {
            winner = (*playroom)[room_index].room_players[0];
            loser = (*playroom)[room_index].room_players[1];
        }
        else
            draw = true;
    }
    else if((*playroom)[room_index].moves[0]==2)
    {
        if((*playroom)[room_index].moves[1]==0)
        {
            winner = (*playroom)[room_index].room_players[1];
            loser = (*playroom)[room_index].room_players[0];
        }
        else if((*playroom)[room_index].moves[1]==1)
        {
            winner = (*playroom)[room_index].room_players[0];
            loser = (*playroom)[room_index].room_players[1];
        }
        else if((*playroom)[room_index].moves[1] == 3)
        {
            winner = (*playroom)[room_index].room_players[0];
            loser = (*playroom)[room_index].room_players[1];
        }
        else
            draw = true;
    }
    else if((*playroom)[room_index].moves[0]==3)
    {
        if((*playroom)[room_index].moves[1]== 3)
        {
            draw = true;
        }
        else
        {
            winner = (*playroom)[room_index].room_players[1];
            loser = (*playroom)[room_index].room_players[0];
        }
    }
    
    for (int i = 0; i< (*players_data).size(); i++)
    {
        if(draw)
        {
            int first_fd , second_fd;
            first_fd = (*playroom)[room_index].room_players[0].player_fd.fd;
            second_fd = (*playroom)[room_index].room_players[1].player_fd.fd;
            send(first_fd, DRAW, strlen(DRAW), 0);
            send(second_fd, DRAW, strlen(DRAW), 0);
        }
        else
        {
            if((*players_data)[i].player_fd.fd == winner.player_fd.fd)
            {
                int fd = winner.player_fd.fd;
                send(fd, WIN, strlen(WIN), 0);
            }
            else if((*players_data)[i].player_fd.fd == loser.player_fd.fd)
            {
                int fd = loser.player_fd.fd;
                send(fd, LOSS, strlen(LOSS), 0);
            }
        }
    }

    if(draw)
    {
        char tmp[256]={0x0};
        winner = (*playroom)[room_index].room_players[0];
        loser = (*playroom)[room_index].room_players[1];
        string first_name = winner.player_name;
        string second_name = loser.player_name;
        int tmp_size = sprintf(tmp,"\n%s draws with %s in room %d.\n",first_name.c_str(),second_name.c_str(),room_index+1);
        int t;
        t = sendto(bc_fd, tmp, tmp_size, 0,(struct sockaddr *)&bc_address, sizeof(bc_address));  
    }
    else
    {
        char tmp[256]={0x0};
        string first_name = winner.player_name;
        string second_name = loser.player_name;
        int tmp_size = sprintf(tmp,"\n%s won %s in room %d.\n",first_name.c_str(),second_name.c_str(),room_index+1);
        int t;
        t = sendto(bc_fd, tmp, tmp_size, 0,(struct sockaddr *)&bc_address, sizeof(bc_address));  
    }
    
    (*playroom)[room_index].moves.clear();
    (*playroom)[room_index].room_players.clear();

    update_players_data(players_data,draw,winner,loser);
}

void add_players_move_to_room (int move_type,int fd,vector<rooms>*playroom , vector<players> *players_data,int bc_fd,struct sockaddr_in bc_address)
{
    for(int i = 0 ; i < (*playroom).size() ; i++)
    {
        if((*playroom)[i].room_players.size() == 2)
        {
            for(int j = 0 ; j < (*playroom)[i].room_players.size();j++)
            {
                if((*playroom)[i].room_players[j].player_fd.fd == fd)
                {
                    (*playroom)[i].moves[j] = move_type;
                    if((*playroom)[i].moves[0]!= -1 && (*playroom)[i].moves[1] != -1)
                        calculate_result(playroom,players_data,i,bc_fd,bc_address);
                    return;
                }
            }
        }
    }
}

int main(int argc, char* argv[])
{
    if(argc != 4)
        perror("Invalid Arguments");

    vector <players> players_data;

    struct sockaddr_in bc_address;
    int server_fd_broadcast;
    char* ipaddr = argv[1];
    struct sockaddr_in server_addr;
    int server_fd_private, opt = 1,broadcast=1;
    std::vector<pollfd> pfds;

    /*Fd for stdin*/
    pollfd temp_fd;
    temp_fd.fd = STDIN;
    temp_fd.events = POLLIN;
    temp_fd.revents = 0;
    pfds.push_back(temp_fd);
    /*------------*/

    /*Fd for host server*/
    server_fd_private = make_host(argv,opt);
    temp_fd.fd = server_fd_private;
    temp_fd.events = POLLIN;
    temp_fd.revents = 0;
    pfds.push_back(temp_fd);
    /*------------*/

    /*Fd for broadcast*/
    server_fd_broadcast = make_broadcast(argv,opt,broadcast,&bc_address);
    temp_fd.fd = server_fd_broadcast;
    temp_fd.events = POLLIN;
    temp_fd.revents = 0;
    pfds.push_back(temp_fd);
    /*---------------*/

    vector<rooms> playroom;
    int num_of_rooms = atoi(argv[3]);
    for(int i = 1 ; i <= num_of_rooms;i++ )
    {
        rooms new_room;
        new_room.room_number = i;
        playroom.push_back(new_room);
    }
    
    write(1, SERVER_LAUNCHED, strlen(SERVER_LAUNCHED));

    while(1)
    {
        if(poll(pfds.data(), (nfds_t)(pfds.size()), -1) == -1)
            perror("FAILED: Poll");
        
        for(size_t i = 0; i < pfds.size(); ++i)
        {
            
            if(pfds[i].revents & POLLIN)
            {
                vector<int> available_rooms = show_available_rooms(playroom);

                if(pfds[i].fd == server_fd_private) // new user
                {
                    struct sockaddr_in new_addr;
                    socklen_t new_size = sizeof(new_addr);
                    int new_fd = accept(server_fd_private, (struct sockaddr*)(&new_addr), &new_size);
                    char tmp[32]={0x0};
                    int tmp_size = sprintf(tmp,"New connection with fd = %d\n",new_fd);
                    write(1, tmp,tmp_size);

                    send(new_fd, ASKING_FOR_NAME, strlen(ASKING_FOR_NAME), 0);

                    pollfd temp_fd;
                    temp_fd.fd = new_fd;
                    temp_fd.events = POLLIN;
                    temp_fd.revents = 0;

                    pfds.push_back(temp_fd);
                }
                else if(pfds[i].fd == STDIN)
                {
                    char buffer[BUFFER_SIZE];
                    memset(buffer, 0, BUFFER_SIZE);
                    read(STDIN, buffer, BUFFER_SIZE);
                    vector <string> words = parse_line(buffer);
                    if(words[0] == END_GAME)
                    {
                        run_end_game(players_data,pfds[2].fd,ipaddr,bc_address);
                        return 0;
                    }
                }
                else // message from user
                {
                    char buffer[BUFFER_SIZE];
                    memset(buffer, 0, BUFFER_SIZE);
                    int ret = recv(pfds[i].fd, buffer, BUFFER_SIZE, 0);
                    if(ret == 0)/*EOF*/
                    {
                        char tmp1[128]={0x0};
                        int tmp1_size = sprintf(tmp1,"Client fd:%d closed.\n",pfds[i].fd);
                        write(1, tmp1, tmp1_size);
                        close(pfds[i].fd);
                        pfds.erase(pfds.begin() + i);
                        break;
                    }
                    vector <string> words = parse_line(buffer);
                    if(words[0] == NAME)
                    {
                        players new_player;
                        string name="";
                        for(int i = 1; i < words.size();i++)
                        {
                           name+=words[i];
                           if(i != words.size()-1)
                           {
                                name+=" ";
                           }
                                 
                        }
                        new_player.num_of_plays=0;
                        new_player.num_of_wins=0;
                        new_player.player_fd=pfds[i];
                        new_player.player_name=name;
                        players_data.push_back(new_player);
                    }        
                    
                    else if(words[0] == SHOW_ROOM)
                    {
                        show_available_rooms(pfds[i].fd,available_rooms);
                    }
                    
                    else if(words[0] == ROOM)
                    {
                        int room_num = atoi(words[1].c_str());
                        if(room_num > playroom.size())
                        {
                            send(pfds[i].fd, ROOM_NOT_EXIST, strlen(ROOM_NOT_EXIST), 0);
                        }
                        else
                        {
                            if(playroom[room_num-1].room_players.size() == 2)
                            {
                                send(pfds[i].fd, ROOM_IS_FULL, strlen(ROOM_IS_FULL), 0);
                            }
                            else
                            {
                                add_player_to_the_room(&playroom,players_data,pfds[i].fd,room_num);
                            }
                        }   
                    }
                    else if(words[0] == MOVE)
                    {
                        int move_type;
                        if(words[1] == ROCK)
                        {
                            move_type = 0;
                        }
                        else if(words[1] == PAPER)
                        {
                            move_type = 1;
                        }
                        else if(words[1] == SCISSOR)
                        {
                            move_type = 2;
                        }
                        else if(words[1] == DO_NOTHING_MOVE)
                        {
                            move_type = 3;
                        }
                        add_players_move_to_room(move_type,pfds[i].fd,&playroom,&players_data,pfds[2].fd,bc_address);
                    }
                    
                    write(1, buffer, strlen(buffer));
                }
            }    
        }
    }
}