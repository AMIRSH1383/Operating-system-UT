#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <cstdlib>
#include <unistd.h>
#include <cstring>
#include <string>
#include <poll.h>
#include <vector>
#include <signal.h>


using namespace std;
typedef struct pollfd pollfd;

#define STDIN 0
#define STDOUT 1
#define BUFFER_SIZE 1024

#define MOVE "Move:"
#define NOTHING "Move: nothing\n"


int make_broadcast(char* argv[],int opt,int broadcast)
{
    struct sockaddr_in bc_address;
    int server_fd_broadcast;

    char* ipaddr = argv[1];

    server_fd_broadcast = socket(AF_INET, SOCK_DGRAM, 0);
    setsockopt(server_fd_broadcast, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(broadcast));
    setsockopt(server_fd_broadcast, SOL_SOCKET, SO_REUSEPORT, &opt, sizeof(opt));

    bc_address.sin_family = AF_INET; 
    bc_address.sin_port = htons(1060); 
    bc_address.sin_addr.s_addr = inet_addr("255.255.255.255");

    bind(server_fd_broadcast, (struct sockaddr *)&bc_address, sizeof(bc_address));

    return server_fd_broadcast;
}

int make_host(char* argv [],int opt)
{   
    struct sockaddr_in server_addr;
    char* ipaddr = argv[1];
    int server_fd_private;
    server_addr.sin_family = AF_INET;
    if(inet_pton(AF_INET, ipaddr, &(server_addr.sin_addr)) == -1)
        perror("FAILED: Input ipv4 address invalid");
    else
        printf("SUCCEED: Input ipv4 address is valid\n");

    if((server_fd_private = socket(PF_INET, SOCK_STREAM, 0)) == -1)
        perror("FAILED: Socket was not created");
    else
        printf("SUCCEED: Socket was created\n");

    if(setsockopt(server_fd_private, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) == -1)
        perror("FAILED: Making socket reusable failed");
    else
        printf("SUCCEED: Making socket reusable succeed\n");

    if(setsockopt(server_fd_private, SOL_SOCKET, SO_REUSEPORT, &opt, sizeof(opt)) == -1)
        perror("FAILED: Making socket reusable port failed");
    else
        printf("SUCCEED: Making socket reusable port succeed\n");

    memset(server_addr.sin_zero, 0, sizeof(server_addr.sin_zero));
    
    server_addr.sin_port = htons(strtol(argv[2], NULL, 10));

    if(connect(server_fd_private, (sockaddr*)(&server_addr), sizeof(server_addr)))
        perror("FAILED: Connect");

    // if(bind(server_fd_private, (const struct sockaddr*)(&server_addr), sizeof(server_addr)) == -1)
    //     perror("FAILED: Bind unsuccessfull");
    // else
    //     printf("SUCCEED: Bind successfull\n");

    // if(listen(server_fd_private, 20) == -1)
    //     perror("FAILED: Listen unsuccessfull");
    // else
    //     printf("SUCCEED: Listen successfull\n");

    return server_fd_private;
}

vector <string> parse_line(char buffer[])
{
    string full_line = buffer;
    vector <string> words;
    for (int i = 0; i<full_line.length();i++)
    {   
        string b ="";
        while(full_line[i] != ' ' && full_line[i] != '\n')
        {
            b+=full_line[i];
            i++;
        }
        words.push_back(b);
    }
    return words;
}

void alarm_handler (int sig)
{
    int server_fd_private = 3;
    send(server_fd_private, NOTHING, strlen(NOTHING), 0);
}

int main(int argc, char* argv[])
{
    bool is_in_game = false;
    if(argc != 3)
        perror("Invalid Arguments");

    char* ipaddr = argv[1];
    struct sockaddr_in server_addr;
    int server_fd_private, opt = 1;
    int server_fd_broadcast , broadcast = 1;

    server_fd_private = make_host(argv,opt);
    server_fd_broadcast = make_broadcast(argv,opt,broadcast);
     
    vector<pollfd>fds;
    pollfd temp1 ={0,POLLIN,0};
    fds.push_back(temp1);
    pollfd temp2 = { server_fd_private,POLLIN,0};
    fds.push_back(temp2);
    pollfd temp3 ={server_fd_broadcast,POLLIN,0};
    fds.push_back(temp3);
    signal(SIGALRM, alarm_handler);
    while(1)
    {
        
        if(poll(fds.data(), (nfds_t)(fds.size()), -1) == -1)
            perror("FAILED: Poll");

        for(size_t i = 0; i < fds.size(); ++i)
        {
            if(fds[i].revents & POLLIN)
            {
                if(fds[i].fd == STDIN)
                {
                    char buffer[BUFFER_SIZE];
                    memset(buffer, 0, BUFFER_SIZE);   
                    read(STDIN,buffer,BUFFER_SIZE);                 
                    vector <string> words = parse_line(buffer);
                    if(words[0] == MOVE && is_in_game == true)
                    {
                        is_in_game = false;
                        alarm(0);
                    }
                    send(server_fd_private, buffer, strlen(buffer), 0);
                }
                else if(fds[i].fd == server_fd_private)
                {
                    char buffer[BUFFER_SIZE];
                    memset(buffer, 0, BUFFER_SIZE);
                    if (recv(server_fd_private, buffer, BUFFER_SIZE, 0) == 0) 
                    {
                        return 0;
                    }
                    vector <string> words = parse_line(buffer);
                    if(words[0] == "Choose" && is_in_game == false)
                    {
                        is_in_game = true;
                        alarm(10);
                    }
                    char tmp[2048]= {0x0};
                    int tmp_size = sprintf(tmp,"Private announcement: %s\n",buffer);
                    write(1, tmp, tmp_size);
                }
                else if(fds[i].fd == server_fd_broadcast) 
                {
                    char buffer[BUFFER_SIZE];
                    memset(buffer, 0, BUFFER_SIZE);
                    if (recv(server_fd_broadcast, buffer, BUFFER_SIZE, 0) == 0) 
                    {
                        return 0;
                    }
                    is_in_game = false;
                    char tmp[2048]= {0x0};
                    int tmp_size = sprintf(tmp,"Public announcement: %s\n",buffer);
                    write(1, tmp, tmp_size);
                }
            }
        }
    }
}