#ifndef _WAV_AUDIO_HPP
#define _WAV_AUDIO_HPP
#include <iostream>
#include <sndfile.h>
#include <vector>
#include <string>
#include <cstring>
#include <cstdlib>

class WavAudio {

private:
    std::vector<float> _data;
    SF_INFO _fileInfo;

    std::string _filepath;



public:
    WavAudio(std::string inputFile);

    void readWavFile();

    void writeWavFile(const std::string& outputFile);

    std::vector<float> get_data();

    void set_data(std::vector<float> data);

};

#endif