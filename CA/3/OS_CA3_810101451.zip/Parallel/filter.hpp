#ifndef _FILTER_HPP
#define _FILTER_HPP

#include "wav.hpp"
#include <vector>
#include <complex>
#include <cmath>
#include "pthread.h"

#define NUM_OF_THREADS 4

using Complex = std::complex<float>;


typedef struct ThreadInfo
{
    std::vector<float>* filter;
    std::vector<float>* data;
    std::vector<float>* output;
    std::vector<float>* a;
    std::vector<float>* b;
    int start;
    int end;
    int filter_size;
    int mid;
    float fL;
    float fH;
    float fs;
    float f0;
    int n;

} ThreadInfo; 

namespace Filter
{
    void band_pass(WavAudio &audio, float f_s);
    void notch(WavAudio &audio,float f_s);
    void finite_impulse_response(WavAudio &audio);
    void infinite_impulse_response(WavAudio &audio);

    std::vector<float> generate_bandpass_filter(int filter_size, float fs, float f_l, float f_h);
    std::vector<float> apply_filter( std::vector<float>& data,  std::vector<float>& filter);
    std::vector<float> apply_IIR_filter(std::vector<float>& data,  std::vector<float>& a,  std::vector<float>& b);

    void* generate_bandpass_filter_parallel(void* arg);
    void* generate_notch_filter_parallel(void* arg);
    void* apply_filter_parallel(void* arg);
    void* apply_IIR_filter_parallel(void* arg);

};

#endif