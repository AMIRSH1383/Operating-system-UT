#include "wav.hpp"


WavAudio:: WavAudio(std::string inputFile)
{
    _filepath = inputFile;
}

void WavAudio:: readWavFile() 
{
    SNDFILE* inFile = sf_open(_filepath.c_str(), SFM_READ, &_fileInfo);
    if (!inFile) {
        std::cerr << "Error opening input file: " << sf_strerror(NULL) << std::endl;
        exit(1);
    }
    
    _data.resize(_fileInfo.frames * _fileInfo.channels);
    sf_count_t numFrames = sf_readf_float(inFile, _data.data(), _fileInfo.frames);
    if (numFrames != _fileInfo.frames) {
        std::cerr << "Error reading frames from file." << std::endl;
        sf_close(inFile);
        exit(1);
    }

    sf_close(inFile);
    std::cout << "Successfully read " << numFrames << " frames from " << _filepath << std::endl;
}

void WavAudio:: writeWavFile(const std::string& outputFile) {
    sf_count_t originalFrames = _fileInfo.frames;
    SNDFILE* outFile = sf_open(outputFile.c_str(), SFM_WRITE, &_fileInfo);
    if (!outFile) {
        std::cerr << "Error opening output file: " << sf_strerror(NULL) << std::endl;
        exit(1);
    }

    sf_count_t numFrames = sf_writef_float(outFile, _data.data(), originalFrames);
    if (numFrames != originalFrames) {
        std::cerr << "Error writing frames to file." << std::endl;
        sf_close(outFile);
        exit(1);
    }

    sf_close(outFile);
    std::cout << "Successfully wrote " << numFrames << " frames to " << outputFile << std::endl;
}

std::vector<float> WavAudio:: get_data() {return _data;}

void WavAudio:: set_data(std::vector<float> data) {_data = data;}