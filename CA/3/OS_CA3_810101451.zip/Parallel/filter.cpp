#include "filter.hpp"

namespace Filter
{
    std::vector<float> generate_bandpass_filter(int filter_size, float fs, float f_l, float f_h) 
    {
        std::vector<float> filter(filter_size);
        int mid = filter_size / 2;
        float fL = f_l / fs; // Lower cutoff frequency
        float fH = f_h / fs; // Upper cutoff frequency

        int num_of_threads = NUM_OF_THREADS; 
        int chunk_size = filter_size / num_of_threads;

        pthread_t threads[num_of_threads];
        ThreadInfo thread_data[num_of_threads];

        for (int i = 0; i < num_of_threads; i++) 
        {
            int start = i * chunk_size;
            int end = (i == num_of_threads - 1) ? filter_size : start + chunk_size;
            thread_data[i].filter = &filter;
            thread_data[i].start = start;
            thread_data[i].end = end;
            thread_data[i].filter_size = filter_size;
            thread_data[i].mid = mid;
            thread_data[i].fH = fH;
            thread_data[i].fL = fL;
            pthread_create(&threads[i], nullptr, generate_bandpass_filter_parallel, &thread_data[i]);
        }

        for (int i = 0; i < num_of_threads; i++) 
        {
            pthread_join(threads[i], nullptr);
        }
        return filter;
    }

    void* generate_bandpass_filter_parallel(void* arg)
    {
        ThreadInfo* data = static_cast<ThreadInfo*>(arg);
        std::vector<float>& filter = *(data->filter);

        for (int i = data->start; i < data->end; i++) 
        {
            float t = i - data->mid;
            float fl_sinc = (t == 0) ? 2 * data->fL : sin(2 * M_PI * data->fL * t) / (M_PI * t);
            float fh_sinc = (t == 0) ? 2 * data->fH : sin(2 * M_PI * data->fH * t) / (M_PI * t);

            filter[i] = fh_sinc - fl_sinc;
            filter[i] *= 0.54 - 0.46 * cos(2 * M_PI * i / (data->filter_size - 1));
        }
        return nullptr;
    }

    std::vector<float> generate_notch_filter(int n, float fs, float f0)
    {
        int filter_size = 2 * n + 1;
        std::vector<float> filter(filter_size+1);
        int mid = filter_size / 2;
        int num_of_threads = NUM_OF_THREADS; 
        int chunk_size = filter_size / num_of_threads;

        pthread_t threads[num_of_threads];
        ThreadInfo thread_data[num_of_threads];

        for (int i = 0; i < num_of_threads; i++) 
        {
            int start = i * chunk_size;
            int end = (i == num_of_threads - 1) ? filter_size : start + chunk_size;
            thread_data[i].filter = &filter;
            thread_data[i].start = start;
            thread_data[i].end = end;
            thread_data[i].filter_size = filter_size;
            thread_data[i].mid = mid;
            thread_data[i].f0 = f0;
            thread_data[i].n = n;
            thread_data[i].fs = fs;
            pthread_create(&threads[i], nullptr, generate_bandpass_filter_parallel, &thread_data[i]);
        }

        for (int i = 0; i < num_of_threads; i++) 
        {
            pthread_join(threads[i], nullptr);
        }
        return filter;
    }

    void* generate_notch_filter_parallel(void* arg)
    {
        ThreadInfo* data = static_cast<ThreadInfo*>(arg);
        std::vector<float>& filter = *(data->filter);
        double bandwidth = 2.0f * data->f0 / data->n;

        for (int i = data->start; i < data->end; i++) 
        {
            float t = (i - data->mid)/data->fs;

            double term1 = (t == 0) ? 1: sin(2 * M_PI * data->f0 *t)/ (2* M_PI* data->f0* t); //sinc(2 * f0 * t)
            double term2 = (t == 0) ? 1: sin((2*M_PI* data->f0 * t)/bandwidth) / (2*M_PI* data->f0 *t)/bandwidth;  //sinc(2 * f0 * t / bandwidth)
            double notch_impulse_response = term1 - term2;

            filter[i] = notch_impulse_response;
            filter[i] *= 0.54 - 0.46 * cos(2 * M_PI * i / (data->filter_size - 1));
        }
        return nullptr;
    }

    std::vector<float> apply_filter( std::vector<float>& data,  std::vector<float>& filter) 
    {
        int N = data.size();
        int filter_size = filter.size();
        int output_size = N + filter_size - 1;

        std::vector<float> output(output_size, 0.0f);

        int num_of_threads = NUM_OF_THREADS;  
        int chunk_size = (output_size + num_of_threads - 1) / num_of_threads;  

        pthread_t threads[num_of_threads];
        ThreadInfo thread_data[num_of_threads];

        for (int i = 0; i < num_of_threads; ++i) 
        {
            int start_index = i * chunk_size;
            int end_index = std::min(start_index + chunk_size, output_size);
            thread_data[i].data = &data; 
            thread_data[i].filter = &filter;
            thread_data[i].output = &output;
            thread_data[i].start = start_index;
            thread_data[i].end = end_index;
            pthread_create(&threads[i], nullptr, apply_filter_parallel, &thread_data[i]);
        }

        // Join all threads
        for (int i = 0; i < num_of_threads; i++) 
        {
            pthread_join(threads[i], nullptr);
        }

        return output;
    }
    
    void* apply_filter_parallel(void* arg) 
    {
        ThreadInfo* data = static_cast<ThreadInfo*>(arg);
        const std::vector<float>& input_data = *(data->data);
        const std::vector<float>& input_filter = *(data->filter);
        std::vector<float>& output = *(data->output);
        int N = input_data.size();
        int filter_size = input_filter.size();

        // Convolution for this chunk
        for (int i = data->start; i < data->end; i++) 
        {
            for (int j = 0; j < filter_size; j++) 
            {
                if (i - j >= 0 && i - j < N) 
                {
                    output[i] += input_data[i - j] * input_filter[j];
                }
            }
        }

        return nullptr;
    }

    std::vector<float> apply_IIR_filter(std::vector<float>& data,  std::vector<float>& a,  std::vector<float>& b) 
    {
        int N = data.size();        
        std::vector<float> output(N, 0.0f);

        int num_of_threads = NUM_OF_THREADS;  
        int chunk_size = (N + num_of_threads - 1) / num_of_threads;  

        pthread_t threads[num_of_threads];
        ThreadInfo thread_data[num_of_threads];

        for (int i = 0; i < num_of_threads; ++i) 
        {
            int start_index = i * chunk_size;
            int end_index = std::min(start_index + chunk_size, N);
            thread_data[i].data = &data; 
            thread_data[i].output = &output;
            thread_data[i].a = &a;
            thread_data[i].b = &b;
            thread_data[i].start = start_index;
            thread_data[i].end = end_index;
            pthread_create(&threads[i], nullptr, apply_IIR_filter_parallel, &thread_data[i]);
        }

        // Join all threads
        for (int i = 0; i < num_of_threads; i++) 
        {
            pthread_join(threads[i], nullptr);
        }
        return output;
    }
    
    void* apply_IIR_filter_parallel(void* arg)
    {
        ThreadInfo* data = static_cast<ThreadInfo*>(arg);
        const std::vector<float>& input_data = *(data->data);
        const std::vector<float>& a = *(data->a);
        const std::vector<float>& b = *(data->b);
        std::vector<float>& output = *(data->output);

        int N_a = a.size();
        int N_b = b.size();

        for (int i = data->start; i < data->end; i++) 
        {
            for (int j = 0; j < N_b; j++) 
            {
                if (i - j >= 0) {
                    output[i] += b[j] * input_data[i - j];
                }
            }
            for (int j = 1; j < N_a; j++) {
                if (i - j >= 0) {
                    output[i] -= a[j] * output[i - j];
                }
            }
        }
        return nullptr;
    }

    void band_pass(WavAudio &audio, float f_s)
    {
        auto the_data = audio.get_data();

        // Signal parameters
        float f_low = 700.0; 
        float f_high = 1400.0;
        int filter_size = 1001; 

        std::vector<float> filter = generate_bandpass_filter(filter_size, f_s, f_low, f_high);
        std::vector<float> filtered_data = apply_filter(the_data, filter);
        
        audio.set_data(filtered_data);
    }

    void notch(WavAudio &audio,float f_s)
    {
        auto the_data = audio.get_data();

        // Signal parameters
        float f0 = 50.0; 
        int n = 500; 

        std::vector<float> filter = generate_notch_filter(n, f_s, f0);
        std::vector<float> filtered_data = apply_filter(the_data, filter);
        
        audio.set_data(filtered_data);
    }

    void finite_impulse_response(WavAudio &audio)
    {
        auto the_data = audio.get_data();
        std::vector<float> coefficients (1000,0.2f);
        std::vector<float> filtered_data = apply_filter(the_data, coefficients);
        audio.set_data(filtered_data);
    }
    
    void infinite_impulse_response(WavAudio &audio)
    {
        auto the_data = audio.get_data();
        std::vector<float> a = {1.0, -0.4};
        std::vector<float> b = {0.3, 0.3};  
        std::vector<float> filtered_data = apply_IIR_filter(the_data, a, b);
        audio.set_data(filtered_data);
    }
}

