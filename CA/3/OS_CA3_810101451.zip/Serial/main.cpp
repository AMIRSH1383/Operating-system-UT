#include "wav.hpp"
#include <chrono>
#include <unistd.h>
#include <fstream>
#include "filter.hpp"

#define SERIAL_OUTPUT_FILE_1 "audio_files/serial_output1.wav"
#define SERIAL_OUTPUT_FILE_2 "audio_files/serial_output2.wav"
#define SERIAL_OUTPUT_FILE_3 "audio_files/serial_output3.wav"
#define SERIAL_OUTPUT_FILE_4 "audio_files/serial_output4.wav"

int main(int argc ,  char* argv[])
{
    if(argc < 2)
    {
        std::cout << "You did not name wav file.\n";
        exit(1);
    }
    auto start = std::chrono::high_resolution_clock::now();
    WavAudio audio(argv[1]);

    auto start_read = std::chrono::high_resolution_clock::now();
    audio.readWavFile();

    auto end_read = std::chrono::high_resolution_clock::now();
    auto start_band_pass = std::chrono::high_resolution_clock::now();
    Filter::band_pass(audio,40000);
    auto end_band_pass = std::chrono::high_resolution_clock::now();
    audio.writeWavFile(SERIAL_OUTPUT_FILE_1);

    audio.readWavFile();
    auto start_notch = std::chrono::high_resolution_clock::now();
    Filter::notch(audio,1000);
    auto end_notch = std::chrono::high_resolution_clock::now();
    audio.writeWavFile(SERIAL_OUTPUT_FILE_2);

    audio.readWavFile();
    auto start_fir = std::chrono::high_resolution_clock::now();
    Filter::finite_impulse_response(audio);
    auto end_fir = std::chrono::high_resolution_clock::now();
    audio.writeWavFile(SERIAL_OUTPUT_FILE_3);

    audio.readWavFile();
    auto start_iir = std::chrono::high_resolution_clock::now();
    Filter::infinite_impulse_response(audio);
    auto end_iir = std::chrono::high_resolution_clock::now();
    audio.writeWavFile(SERIAL_OUTPUT_FILE_4);

    auto end = std::chrono::high_resolution_clock::now();

    std::cout << "Read: " << std::chrono::duration_cast<std::chrono::milliseconds>(end_read - start_read).count() << " ms" << std::endl;
    std::cout << "Band pass: " << std::chrono::duration_cast<std::chrono::milliseconds>(end_band_pass - start_band_pass).count() << " ms" << std::endl;
    std::cout << "Notch: " << std::chrono::duration_cast<std::chrono::milliseconds>(end_notch - start_notch).count() << " ms" << std::endl;
    std::cout << "Finite impulse response: " << std::chrono::duration_cast<std::chrono::milliseconds>(end_fir - start_fir).count() << " ms" << std::endl;
    std::cout << "Infinite impulse response: " << std::chrono::duration_cast<std::chrono::milliseconds>(end_iir - start_iir).count() << " ms" << std::endl;
    std::cout << "Execution: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << " ms" << std::endl;

    return 0;

}