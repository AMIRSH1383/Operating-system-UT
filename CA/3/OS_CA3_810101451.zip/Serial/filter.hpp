#ifndef _FILTER_HPP
#define _FILTER_HPP

#include "wav.hpp"
#include <vector>
#include <complex>
#include <cmath>

using Complex = std::complex<float>;

namespace Filter
{
    void band_pass(WavAudio &audio, float f_s);
    void notch(WavAudio &audio,float f_s);
    void finite_impulse_response(WavAudio &audio);
    void infinite_impulse_response(WavAudio &audio);

    std::vector<float> generate_bandpass_filter(int filter_size, float fs, float f_l, float f_h);
    std::vector<float> apply_filter(const std::vector<float>& data, const std::vector<float>& filter);

};

#endif