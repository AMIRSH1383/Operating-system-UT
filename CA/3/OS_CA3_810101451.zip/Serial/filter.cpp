#include "filter.hpp"


namespace Filter
{
    std::vector<float> generate_bandpass_filter(int filter_size, float fs, float f_l, float f_h) 
    {
        std::vector<float> filter(filter_size );
        int mid = filter_size / 2;
        float fL = f_l / fs; // Lower cutoff frequency
        float fH = f_h / fs; // Upper cutoff frequency

        for (int i = 0; i < filter_size; i++) 
        {
            float t = i - mid;
            float fl_sinc = (t == 0) ? 2 * fL : sin(2 * M_PI * fL * t) / (M_PI * t);
            float fh_sinc = (t == 0) ? 2 * fH : sin(2 * M_PI * fH * t) / (M_PI * t);

            // h(t)
            filter[i] = fh_sinc - fl_sinc;

            // Apply Hamming window
            filter[i] *= 0.54 - 0.46 * cos(2 * M_PI *  t / filter_size);
        }
        return filter;
    }

    std::vector<float> generate_notch_filter(int n, float fs, float f0)
    {
        int filter_size = 2 * n + 1;
        std::vector<float> filter(filter_size);
        int mid = filter_size / 2;

        double bandwidth = 2.0f * f0 / n;

        for(int i = 0; i < filter_size  ;i++)
        {
            double t = (i - mid)/fs;

            double term1 = (t == 0) ? 1: sin(2 * M_PI * f0 *t)/ (2*M_PI*f0*t); //sinc(2 * f0 * t)
            double term2 = (t == 0) ? 1: sin((2*M_PI*f0*t)/bandwidth) / (2*M_PI*f0*t)/bandwidth;  //sinc(2 * f0 * t / bandwidth)
            double notch_impulse_response = term1 - term2;

            filter[i] = notch_impulse_response;

            // Apply Hamming window
            filter[i] *= 0.54 - 0.46 * cos(2 * M_PI *  t / filter_size);
        }

        return filter;
    }

    std::vector<float> apply_filter(const std::vector<float>& data, const std::vector<float>& filter) 
    {
        int N = data.size();
        int filter_size = filter.size();
        int output_size = N + filter_size - 1;

        std::vector<float> output(output_size, 0.0f);

        // Covolution
        for (int i = 0; i < output_size; ++i) 
        {
            for (int j = 0; j < filter_size; ++j) 
            {
                if (i - j >= 0 && i - j < N) 
                {
                    output[i] += data[i - j] * filter[j];
                }
            }
        }
        return output;
    }

    std::vector<float> apply_IIR_filter(const std::vector<float>& data, const std::vector<float>& a, const std::vector<float>& b) 
    {
        int N = data.size();    
        int N_b = b.size();        
        int N_a = a.size();       

        std::vector<float> output(N, 0.0f);

        for (int i = 0; i < N; i++) 
        {
            for (int j = 0; j < N_b; j++) 
            {
                if (i - j >= 0) {
                    output[i] += b[j] * data[i - j];
                }
            }
            for (int j = 1; j < N_a; j++) {
                if (i - j >= 0) {
                    output[i] -= a[j] * output[i - j];
                }
            }
        }

        return output;
    }
    
    void band_pass(WavAudio &audio, float f_s)
    {
        auto the_data = audio.get_data();

        // Signal parameters
        float f_low = 700.0; 
        float f_high = 1400.0;
        int filter_size = 1001; 

        std::vector<float> filter = generate_bandpass_filter(filter_size, f_s, f_low, f_high);
        std::vector<float> filtered_data = apply_filter(the_data, filter);
        
        audio.set_data(filtered_data);
    }

    void notch(WavAudio &audio,float f_s)
    {
        auto the_data = audio.get_data();

        // Signal parameters
        float f0 = 50.0; 
        int n = 500; 

        std::vector<float> filter = generate_notch_filter(n, f_s, f0);
        std::vector<float> filtered_data = apply_filter(the_data, filter);
        
        audio.set_data(filtered_data);
    }

    void finite_impulse_response(WavAudio &audio)
    {
        auto the_data = audio.get_data();
        std::vector<float> coefficients (1000,0.2f);
        std::vector<float> filtered_data = apply_filter(the_data, coefficients);
        audio.set_data(filtered_data);
    }
    
    void infinite_impulse_response(WavAudio &audio)
    {
        auto the_data = audio.get_data();
        std::vector<float> a = {1.0, -0.4};
        std::vector<float> b = {0.3, 0.3};  
        std::vector<float> filtered_data = apply_IIR_filter(the_data, a, b);
        audio.set_data(filtered_data);
    }
}

